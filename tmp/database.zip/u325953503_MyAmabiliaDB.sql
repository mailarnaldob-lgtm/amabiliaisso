-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2025 at 03:19 PM
-- Server version: 11.8.3-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u325953503_MyAmabiliaDB`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `approve_task_proof` (IN `p_proof_id` BIGINT, IN `p_admin_id` BIGINT)   BEGIN
  DECLARE v_user_id BIGINT;
  DECLARE v_task_id INT;
  DECLARE v_reward DECIMAL(10,2);

  -- Lock proof row
  SELECT tp.user_id, tp.task_id, t.reward_amount
  INTO v_user_id, v_task_id, v_reward
  FROM task_proofs tp
  JOIN tasks t ON t.id = tp.task_id
  WHERE tp.id = p_proof_id
    AND tp.status = 'pending'
  FOR UPDATE;

  IF v_user_id IS NULL THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Invalid or already processed task proof';
  END IF;

  -- Enforce cooldown + PER-USER quota (fixed logic)
  CALL validate_task_limits(v_user_id, v_task_id);

  -- Approve proof
  UPDATE task_proofs
  SET status = 'approved',
      updated_at = NOW()
  WHERE id = p_proof_id;

  -- Credit payout + audit
  CALL credit_task_payout(
    v_user_id,
    v_task_id,
    v_reward,
    p_admin_id
  );

  -- Mark proof as paid
  UPDATE task_proofs
  SET status = 'paid',
      updated_at = NOW()
  WHERE id = p_proof_id;

END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `attempt_loan_deduction` (IN `p_user_id` BIGINT, IN `p_amount` DECIMAL(18,2))   BEGIN
  DECLARE remaining DECIMAL(18,2);
  DECLARE taken DECIMAL(18,2);

  SET remaining = p_amount;

  -- TASK wallet
  SELECT LEAST(balance, remaining) INTO taken
  FROM wallets WHERE user_id = p_user_id AND wallet_type = 'task';
  IF taken > 0 THEN
    UPDATE wallets SET balance = balance - taken
    WHERE user_id = p_user_id AND wallet_type = 'task';
    INSERT INTO wallet_transactions
      (user_id, wallet_type, amount, type, source, note, created_at)
    VALUES (p_user_id, 'task', taken, 'loan_repayment', 'auto', 'Auto-deduction (task)', NOW());
    SET remaining = remaining - taken;
  END IF;

  -- ROYALTY wallet
  IF remaining > 0 THEN
    SELECT LEAST(balance, remaining) INTO taken
    FROM wallets WHERE user_id = p_user_id AND wallet_type = 'royalty';
    IF taken > 0 THEN
      UPDATE wallets SET balance = balance - taken
      WHERE user_id = p_user_id AND wallet_type = 'royalty';
      INSERT INTO wallet_transactions
        (user_id, wallet_type, amount, type, source, note, created_at)
      VALUES (p_user_id, 'royalty', taken, 'loan_repayment', 'auto', 'Auto-deduction (royalty)', NOW());
      SET remaining = remaining - taken;
    END IF;
  END IF;

  -- MAIN wallet
  IF remaining > 0 THEN
    SELECT LEAST(balance, remaining) INTO taken
    FROM wallets WHERE user_id = p_user_id AND wallet_type = 'main';
    IF taken > 0 THEN
      UPDATE wallets SET balance = balance - taken
      WHERE user_id = p_user_id AND wallet_type = 'main';
      INSERT INTO wallet_transactions
        (user_id, wallet_type, amount, type, source, note, created_at)
      VALUES (p_user_id, 'main', taken, 'loan_repayment', 'auto', 'Auto-deduction (main)', NOW());
      SET remaining = remaining - taken;
    END IF;
  END IF;
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `complete_rescue_task` (IN `p_rescue_id` INT)   BEGIN
  DECLARE v_loan_id BIGINT;
  DECLARE v_amount DECIMAL(10,2);

  -- Lock and fetch rescue task
  SELECT loan_id, applied_amount
  INTO v_loan_id, v_amount
  FROM rescue_tasks
  WHERE id = p_rescue_id
    AND status = 'assigned'
  FOR UPDATE;

  IF v_loan_id IS NULL THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Invalid or already processed rescue task';
  END IF;

  -- Apply loan deduction using existing engine
  CALL attempt_loan_deduction(v_loan_id, v_amount);

  -- Mark rescue task completed
  UPDATE rescue_tasks
  SET status = 'completed'
  WHERE id = p_rescue_id;
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `create_rescue_task` (IN `p_loan_id` BIGINT, IN `p_user_id` BIGINT, IN `p_task_id` INT, IN `p_amount` DECIMAL(10,2))   BEGIN
  -- Validate user exists
  IF NOT EXISTS (
    SELECT 1 FROM users WHERE id = p_user_id
  ) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Invalid user_id: user does not exist';
  END IF;

  -- Validate loan exists
  IF NOT EXISTS (
    SELECT 1 FROM loans WHERE id = p_loan_id
  ) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Invalid loan_id: loan does not exist';
  END IF;

  -- Validate task exists
  IF NOT EXISTS (
    SELECT 1 FROM tasks WHERE id = p_task_id
  ) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Invalid task_id: task does not exist';
  END IF;

  -- Insert rescue task
  INSERT INTO rescue_tasks (
    loan_id,
    user_id,
    task_id,
    applied_amount,
    status
  ) VALUES (
    p_loan_id,
    p_user_id,
    p_task_id,
    p_amount,
    'assigned'
  );
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `credit_referral_commission` (IN `p_referrer_id` BIGINT, IN `p_base_amount` DECIMAL(18,2), IN `p_source` VARCHAR(100))   BEGIN
    DECLARE v_rate DECIMAL(5,2);
    DECLARE v_commission DECIMAL(18,2);

    -- Fetch referral rate dynamically
    SELECT CAST(setting_value AS DECIMAL(5,2))
    INTO v_rate
    FROM system_settings
    WHERE setting_key = 'referral_rate'
    LIMIT 1;

    SET v_commission = p_base_amount * (v_rate / 100);

    -- Credit MAIN wallet
    UPDATE wallets
    SET balance = balance + v_commission
    WHERE user_id = p_referrer_id
      AND wallet_type = 'main';

    -- Wallet transaction (COLUMN-SAFE)
    INSERT INTO wallet_transactions
        (user_id, wallet_type, amount, type, source, note, created_at)
    VALUES
        (p_referrer_id, 'main', v_commission, 'credit', p_source, 'Referral commission', NOW());

    -- Commission audit (matches table schema)
    INSERT INTO commission_audit
        (event_type, source_user_id, target_user_id, amount, percent_applied, notes, source, user_id)
    VALUES
        ('referral', NULL, p_referrer_id, v_commission, v_rate, 'Referral commission applied', p_source, p_referrer_id);
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `credit_task_payout` (IN `p_user_id` BIGINT, IN `p_task_id` INT, IN `p_amount` DECIMAL(10,2), IN `p_admin_id` BIGINT, IN `p_proof_id` BIGINT)   BEGIN
  DECLARE v_wallet_id BIGINT;

  /* Lock wallet */
  SELECT id
  INTO v_wallet_id
  FROM wallets
  WHERE user_id = p_user_id
  LIMIT 1
  FOR UPDATE;

  IF v_wallet_id IS NULL THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Wallet not found for user';
  END IF;

  /* Credit wallet balance */
  UPDATE wallets
  SET balance = balance + p_amount
  WHERE id = v_wallet_id;

  /* Wallet transaction log */
  INSERT INTO wallet_transactions (
    wallet_id,
    amount,
    type,
    description,
    created_at
  ) VALUES (
    v_wallet_id,
    p_amount,
    'credit',
    CONCAT('Task reward payout (Task ID: ', p_task_id, ')'),
    NOW()
  );

  /* Immutable audit ledger */
  INSERT INTO commission_audit (
    event_type,
    source_user_id,
    user_id,
    amount,
    source,
    reference_type,
    reference_id,
    notes,
    created_at
  ) VALUES (
    'TASK_PAYOUT',
    p_admin_id,
    p_user_id,
    p_amount,
    'task_reward',
    'task_proof',
    p_proof_id,
    CONCAT('Task payout approved by admin ID ', p_admin_id),
    NOW()
  );

END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `distribute_task_reward` (IN `p_user_id` BIGINT, IN `p_task_id` BIGINT, IN `p_reward` DECIMAL(18,2))   BEGIN
    DECLARE v_upline BIGINT;
    DECLARE v_rate DECIMAL(5,2);
    DECLARE v_royalty DECIMAL(18,2);
    DECLARE v_net DECIMAL(18,2);

    -- Get upline
    SELECT referrer_id INTO v_upline
    FROM users
    WHERE id = p_user_id;

    -- Get royalty rate
    SELECT CAST(setting_value AS DECIMAL(5,2))
    INTO v_rate
    FROM system_settings
    WHERE setting_key = 'royalty_rate'
    LIMIT 1;

    SET v_royalty = p_reward * (v_rate / 100);
    SET v_net = p_reward - v_royalty;

    -- Credit worker TASK wallet
    UPDATE wallets
    SET balance = balance + v_net
    WHERE user_id = p_user_id
      AND wallet_type = 'task';

    INSERT INTO wallet_transactions
        (user_id, wallet_type, amount, type, source, note, created_at)
    VALUES
        (p_user_id, 'task', v_net, 'credit', 'task', 'Task reward (net)', NOW());

    -- Credit upline ROYALTY wallet
    IF v_upline IS NOT NULL THEN
        UPDATE wallets
        SET balance = balance + v_royalty
        WHERE user_id = v_upline
          AND wallet_type = 'royalty';

        INSERT INTO wallet_transactions
            (user_id, wallet_type, amount, type, source, note, created_at)
        VALUES
            (v_upline, 'royalty', v_royalty, 'credit', 'task', 'Royalty override', NOW());

        INSERT INTO royalties
            (upline_id, downline_id, task_id, royalty_amount)
        VALUES
            (v_upline, p_user_id, p_task_id, v_royalty);
    END IF;
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `generate_loan_schedule` (IN `p_loan_id` BIGINT, IN `p_total` DECIMAL(18,2), IN `p_days` INT)   BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE daily DECIMAL(18,2);

  SET daily = p_total / p_days;

  WHILE i <= p_days DO
    INSERT INTO loan_schedules (loan_id, due_date, amount_due)
    VALUES (p_loan_id, DATE_ADD(CURDATE(), INTERVAL i DAY), daily);
    SET i = i + 1;
  END WHILE;
END$$

CREATE DEFINER=`u325953503_database111`@`127.0.0.1` PROCEDURE `validate_task_limits` (IN `p_user_id` BIGINT, IN `p_task_id` INT)   BEGIN
  DECLARE v_cooldown INT;
  DECLARE v_last_paid DATETIME;
  DECLARE v_daily_quota INT;
  DECLARE v_today_count INT;

  -- Get task rules
  SELECT cooldown_minutes, daily_quota
  INTO v_cooldown, v_daily_quota
  FROM tasks
  WHERE id = p_task_id
    AND status = 'active';

  IF v_cooldown IS NULL THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Task not active or does not exist';
  END IF;

  -- Cooldown check (per user, per task)
  SELECT MAX(updated_at)
  INTO v_last_paid
  FROM task_proofs
  WHERE user_id = p_user_id
    AND task_id = p_task_id
    AND status = 'paid';

  IF v_last_paid IS NOT NULL
     AND TIMESTAMPDIFF(MINUTE, v_last_paid, NOW()) < v_cooldown THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Task cooldown not yet expired';
  END IF;

  -- Daily quota check (PER USER)
  IF v_daily_quota IS NOT NULL THEN
    SELECT COUNT(*)
    INTO v_today_count
    FROM task_proofs
    WHERE user_id = p_user_id
      AND task_id = p_task_id
      AND status IN ('approved','paid')
      AND DATE(created_at) = CURDATE();

    IF v_today_count >= v_daily_quota THEN
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Daily task quota reached';
    END IF;
  END IF;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('super','operator') NOT NULL DEFAULT 'operator',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password_hash`, `role`, `created_at`) VALUES
(1, 'admin@amabilianetwork.com', '$2y$10$9oEo6iIYxc1P6CVaHb5lFOtHVx5rXgPtSatO6s1lOdFo0xy7qNoSi', 'super', '2025-12-10 20:08:18'),
(2, 'amabilia_admin', '$2y$10$sRZdaTLl1wGpcEAlJpqpBupTqis6Odhaylr5R7gZ9GsH.rP5h2y0C', 'operator', '2025-12-11 03:39:17');

-- --------------------------------------------------------

--
-- Table structure for table `admin_logs`
--

CREATE TABLE `admin_logs` (
  `id` bigint(20) NOT NULL,
  `admin_id` bigint(20) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `army_levels`
--

CREATE TABLE `army_levels` (
  `id` int(11) NOT NULL,
  `level_name` varchar(50) NOT NULL,
  `min_tasks_completed` int(11) DEFAULT 0,
  `min_quality_score` decimal(5,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `army_levels`
--

INSERT INTO `army_levels` (`id`, `level_name`, `min_tasks_completed`, `min_quality_score`, `created_at`) VALUES
(1, 'Cadet', 0, 0.00, '2025-12-13 07:48:01'),
(2, 'Specialist', 50, 70.00, '2025-12-13 07:48:01'),
(3, 'Operative', 150, 80.00, '2025-12-13 07:48:01'),
(4, 'Vanguard', 300, 90.00, '2025-12-13 07:48:01'),
(5, 'Elite Operator', 600, 95.00, '2025-12-13 07:48:01');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_tasks`
--

CREATE TABLE `campaign_tasks` (
  `id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `commission_audit`
--

CREATE TABLE `commission_audit` (
  `id` int(11) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `source_user_id` int(11) DEFAULT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `percent_applied` decimal(5,2) NOT NULL,
  `notes` varchar(512) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_wallets`
--

CREATE TABLE `company_wallets` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `balance` decimal(18,2) NOT NULL DEFAULT 0.00,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_wallets`
--

INSERT INTO `company_wallets` (`id`, `name`, `balance`, `meta`) VALUES
(1, 'company_main', 18000.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `engagement_campaigns`
--

CREATE TABLE `engagement_campaigns` (
  `id` int(11) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `campaign_title` varchar(255) DEFAULT NULL,
  `campaign_type` enum('comments','shares','ugc','feedback') NOT NULL,
  `total_budget` decimal(12,2) NOT NULL,
  `status` enum('pending','approved','running','completed') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fraud_flags`
--

CREATE TABLE `fraud_flags` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `flag_type` varchar(100) DEFAULT NULL,
  `risk_level` enum('low','medium','high') DEFAULT 'low',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fraud_flags`
--

INSERT INTO `fraud_flags` (`id`, `user_id`, `flag_type`, `risk_level`, `notes`, `created_at`) VALUES
(1, 2, 'baseline_check', 'low', 'Initial baseline', '2025-12-12 20:14:27'),
(2, 1, 'baseline_check', 'low', 'Initial baseline', '2025-12-12 20:14:27');

-- --------------------------------------------------------

--
-- Table structure for table `kyc_documents`
--

CREATE TABLE `kyc_documents` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `uploaded_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `id` bigint(20) NOT NULL,
  `lender_id` bigint(20) NOT NULL,
  `borrower_id` bigint(20) NOT NULL,
  `principal` decimal(18,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `term_days` int(11) NOT NULL,
  `status` enum('pending','active','completed','defaulted') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `rescue_eligible` tinyint(1) DEFAULT 0,
  `rescue_used_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan_schedules`
--

CREATE TABLE `loan_schedules` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `due_date` date NOT NULL,
  `amount_due` decimal(18,2) NOT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tier` enum('basic','pro','elite') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `purchased_at` timestamp NULL DEFAULT current_timestamp(),
  `payment_gateway` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `user_id`, `tier`, `amount`, `purchased_at`, `payment_gateway`, `is_active`) VALUES
(1, 1, 'pro', 2000.00, '2025-12-10 19:25:05', NULL, 0),
(2, 1, 'elite', 3000.00, '2025-12-10 19:29:07', NULL, 0),
(3, 1, 'elite', 3000.00, '2025-12-10 19:29:07', NULL, 0),
(4, 1, 'pro', 2000.00, '2025-12-10 19:29:10', NULL, 0),
(5, 1, 'basic', 1000.00, '2025-12-11 02:05:48', NULL, 0),
(6, 1, 'basic', 1000.00, '2025-12-11 02:05:53', NULL, 0),
(7, 1, 'basic', 1000.00, '2025-12-11 02:06:06', NULL, 0),
(8, 1, 'pro', 2000.00, '2025-12-11 02:06:13', NULL, 0),
(9, 1, 'pro', 2000.00, '2025-12-11 02:06:14', NULL, 0),
(10, 1, 'basic', 1000.00, '2025-12-12 15:50:02', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('gcash','maya','bank') NOT NULL,
  `reference_code` varchar(50) NOT NULL,
  `proof_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','for_verification','approved','rejected','expired') DEFAULT 'pending',
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_audit_logs`
--

CREATE TABLE `payment_audit_logs` (
  `id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` enum('approve','reject') NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_qr_codes`
--

CREATE TABLE `payment_qr_codes` (
  `id` int(11) NOT NULL,
  `method` enum('gcash','maya','bank') NOT NULL,
  `qr_image` varchar(255) NOT NULL,
  `receiver_name` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `referrer_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `commission_amount` decimal(18,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rescue_tasks`
--

CREATE TABLE `rescue_tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL,
  `applied_amount` decimal(10,2) NOT NULL,
  `status` enum('assigned','completed','failed') DEFAULT 'assigned',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `royalties`
--

CREATE TABLE `royalties` (
  `id` bigint(20) NOT NULL,
  `upline_id` bigint(20) NOT NULL,
  `downline_id` bigint(20) NOT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `royalty_amount` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` bigint(20) NOT NULL,
  `setting_key` varchar(150) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'referral_rate', '40', '2025-12-12 18:50:34'),
(2, 'royalty_rate', '10', '2025-12-13 03:06:21'),
(3, 'membership_basic_price', '1000', '2025-12-12 20:11:03'),
(4, 'membership_pro_price', '2000', '2025-12-12 20:11:03'),
(5, 'membership_elite_price', '3000', '2025-12-12 20:11:03'),
(10, 'global_kill_switch', 'off', '2025-12-15 09:16:09'),
(11, 'registrations_enabled', 'on', '2025-12-15 09:16:09'),
(12, 'wallets_enabled', 'on', '2025-12-15 09:16:09');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `reward` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `difficulty` enum('easy','medium','hard') DEFAULT 'easy',
  `status` enum('active','paused','completed') DEFAULT 'active',
  `proof_required` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_proofs`
--

CREATE TABLE `task_proofs` (
  `id` int(11) NOT NULL,
  `task_id` int(11) DEFAULT NULL,
  `reward_amount` decimal(10,2) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `proof_text` varchar(1024) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `proof_url` varchar(500) DEFAULT NULL,
  `qa_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_reviews`
--

CREATE TABLE `task_reviews` (
  `id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `decision` enum('approved','rejected') NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_submissions`
--

CREATE TABLE `task_submissions` (
  `id` bigint(20) NOT NULL,
  `task_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `proof` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions_legacy`
--

CREATE TABLE `transactions_legacy` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions_legacy`
--

INSERT INTO `transactions_legacy` (`id`, `user_id`, `amount`, `type`, `description`, `created_at`) VALUES
(1, 1, 2000.00, 'membership', 'Purchased pro membership', '2025-12-10 19:25:05'),
(2, 1, 3000.00, 'membership', 'Purchased elite membership', '2025-12-10 19:29:07'),
(3, 1, 3000.00, 'membership', 'Purchased elite membership', '2025-12-10 19:29:07'),
(4, 1, 2000.00, 'membership', 'Purchased pro membership', '2025-12-10 19:29:10'),
(5, 1, 1000.00, 'membership', 'Purchased basic membership', '2025-12-11 02:05:48'),
(6, 1, 1000.00, 'membership', 'Purchased basic membership', '2025-12-11 02:05:53'),
(7, 1, 1000.00, 'membership', 'Purchased basic membership', '2025-12-11 02:06:06'),
(8, 1, 2000.00, 'membership', 'Purchased pro membership', '2025-12-11 02:06:13'),
(9, 1, 2000.00, 'membership', 'Purchased pro membership', '2025-12-11 02:06:14'),
(10, 1, 1000.00, 'membership', 'Purchased basic membership', '2025-12-12 15:50:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `fullname` varchar(255) DEFAULT NULL,
  `referrer_id` bigint(20) DEFAULT NULL,
  `membership_tier` enum('basic','pro','elite') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `created_at`, `fullname`, `referrer_id`, `membership_tier`) VALUES
(1, 'test@example.com', '$2y$10$yohmEkZGuwAl510S8FAf1emRR38yjRCx/NedSMgeF4ed0bwJvryn2', '2025-12-10 19:24:22', NULL, NULL, 'basic'),
(2, 'clintbryanflores79@gmail.com', '$2y$10$6I9zmJVtPLymAR8QgsgK9O4OYFB7ebUIgOhK4.TFBPya1w0nLu8fm', '2025-12-10 19:38:15', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_army_profiles`
--

CREATE TABLE `user_army_profiles` (
  `user_id` int(11) NOT NULL,
  `army_level_id` int(11) DEFAULT 1,
  `total_tasks_completed` int(11) DEFAULT 0,
  `quality_score` decimal(5,2) DEFAULT 0.00,
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_tokens`
--

CREATE TABLE `user_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_task_payout_audit`
-- (See below for the actual view)
--
CREATE TABLE `v_task_payout_audit` (
`proof_id` int(11)
,`user_id` int(11)
,`user_email` varchar(255)
,`task_id` int(11)
,`reward_amount` decimal(10,2)
,`proof_status` enum('pending','approved','rejected')
,`audit_id` int(11)
,`credited_amount` decimal(18,2)
,`audit_source` varchar(100)
,`reference_type` varchar(50)
,`reference_id` bigint(20)
,`paid_at` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `wallet_type` enum('task','royalty','main') NOT NULL,
  `balance` decimal(18,2) NOT NULL DEFAULT 0.00,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `wallet_type`, `balance`, `updated_at`, `meta`) VALUES
(1, 1, 'task', 0.00, '2025-12-13 03:11:00', NULL),
(2, 1, 'royalty', 0.00, '2025-12-12 18:50:33', NULL),
(3, 1, 'main', 0.00, '2025-12-13 03:24:21', NULL),
(4, 2, 'task', 0.00, '2025-12-12 18:50:33', NULL),
(5, 2, 'royalty', 0.00, '2025-12-12 18:50:33', NULL),
(6, 2, 'main', 0.00, '2025-12-12 18:50:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `wallet_type` enum('task','royalty','main') DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `type` enum('credit','debit') NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `note` varchar(512) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `post_balance` decimal(18,2) DEFAULT NULL,
  `reference` varchar(128) DEFAULT NULL,
  `txn_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `army_levels`
--
ALTER TABLE `army_levels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `level_name` (`level_name`);

--
-- Indexes for table `campaign_tasks`
--
ALTER TABLE `campaign_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `campaign_id` (`campaign_id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `commission_audit`
--
ALTER TABLE `commission_audit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_source_user` (`source_user_id`),
  ADD KEY `idx_target_user` (`target_user_id`),
  ADD KEY `idx_commission_reference` (`reference_type`,`reference_id`);

--
-- Indexes for table `company_wallets`
--
ALTER TABLE `company_wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `engagement_campaigns`
--
ALTER TABLE `engagement_campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fraud_flags`
--
ALTER TABLE `fraud_flags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `kyc_documents`
--
ALTER TABLE `kyc_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_loans_id` (`id`),
  ADD KEY `lender_id` (`lender_id`),
  ADD KEY `borrower_id` (`borrower_id`);

--
-- Indexes for table `loan_schedules`
--
ALTER TABLE `loan_schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loan_id` (`loan_id`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_memberships_user` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payments_user` (`user_id`),
  ADD KEY `idx_payments_reference` (`reference_code`);

--
-- Indexes for table `payment_audit_logs`
--
ALTER TABLE `payment_audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_audit_payment` (`payment_id`);

--
-- Indexes for table `payment_qr_codes`
--
ALTER TABLE `payment_qr_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payment_method` (`method`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_referrals_referrer` (`referrer_id`),
  ADD KEY `idx_referrals_user` (`user_id`);

--
-- Indexes for table `rescue_tasks`
--
ALTER TABLE `rescue_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rescue_once` (`loan_id`,`task_id`),
  ADD KEY `idx_rescue_user_id` (`user_id`),
  ADD KEY `idx_rescue_loan_id` (`loan_id`),
  ADD KEY `idx_rescue_task_id` (`task_id`);

--
-- Indexes for table `royalties`
--
ALTER TABLE `royalties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `upline_id` (`upline_id`),
  ADD KEY `downline_id` (`downline_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tasks_status` (`status`);

--
-- Indexes for table `task_proofs`
--
ALTER TABLE `task_proofs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_user_task_pending` (`user_id`,`task_id`,`status`),
  ADD KEY `idx_taskproofs_task` (`task_id`);

--
-- Indexes for table `task_reviews`
--
ALTER TABLE `task_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_review_submission` (`submission_id`);

--
-- Indexes for table `task_submissions`
--
ALTER TABLE `task_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_submission_user` (`user_id`),
  ADD KEY `idx_task_user` (`task_id`,`user_id`);

--
-- Indexes for table `transactions_legacy`
--
ALTER TABLE `transactions_legacy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_army_profiles`
--
ALTER TABLE `user_army_profiles`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `army_level_id` (`army_level_id`);

--
-- Indexes for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_tokens_user` (`user_id`),
  ADD KEY `idx_user_tokens_token` (`token`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_wallets_userid` (`user_id`);

--
-- Indexes for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_wtx_userid` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_logs`
--
ALTER TABLE `admin_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `army_levels`
--
ALTER TABLE `army_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `campaign_tasks`
--
ALTER TABLE `campaign_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commission_audit`
--
ALTER TABLE `commission_audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_wallets`
--
ALTER TABLE `company_wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `engagement_campaigns`
--
ALTER TABLE `engagement_campaigns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fraud_flags`
--
ALTER TABLE `fraud_flags`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kyc_documents`
--
ALTER TABLE `kyc_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_schedules`
--
ALTER TABLE `loan_schedules`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_audit_logs`
--
ALTER TABLE `payment_audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_qr_codes`
--
ALTER TABLE `payment_qr_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rescue_tasks`
--
ALTER TABLE `rescue_tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `royalties`
--
ALTER TABLE `royalties`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_proofs`
--
ALTER TABLE `task_proofs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_reviews`
--
ALTER TABLE `task_reviews`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_submissions`
--
ALTER TABLE `task_submissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions_legacy`
--
ALTER TABLE `transactions_legacy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_tokens`
--
ALTER TABLE `user_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

-- --------------------------------------------------------

--
-- Structure for view `v_task_payout_audit`
--
DROP TABLE IF EXISTS `v_task_payout_audit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u325953503_database111`@`127.0.0.1` SQL SECURITY DEFINER VIEW `v_task_payout_audit`  AS SELECT `tp`.`id` AS `proof_id`, `tp`.`user_id` AS `user_id`, `u`.`email` AS `user_email`, `tp`.`task_id` AS `task_id`, `tp`.`reward_amount` AS `reward_amount`, `tp`.`status` AS `proof_status`, `ca`.`id` AS `audit_id`, `ca`.`amount` AS `credited_amount`, `ca`.`source` AS `audit_source`, `ca`.`reference_type` AS `reference_type`, `ca`.`reference_id` AS `reference_id`, `ca`.`created_at` AS `paid_at` FROM ((`task_proofs` `tp` join `users` `u` on(`u`.`id` = `tp`.`user_id`)) left join `commission_audit` `ca` on(`ca`.`reference_type` = 'task_proof' and `ca`.`reference_id` = `tp`.`id` and `ca`.`source` = 'task_reward')) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `campaign_tasks`
--
ALTER TABLE `campaign_tasks`
  ADD CONSTRAINT `campaign_tasks_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `engagement_campaigns` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `campaign_tasks_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `memberships`
--
ALTER TABLE `memberships`
  ADD CONSTRAINT `fk_memberships_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_memberships_user_v2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `memberships_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_audit_logs`
--
ALTER TABLE `payment_audit_logs`
  ADD CONSTRAINT `fk_audit_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `referrals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `referrals_ibfk_2` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `task_proofs`
--
ALTER TABLE `task_proofs`
  ADD CONSTRAINT `fk_task_proofs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_reviews`
--
ALTER TABLE `task_reviews`
  ADD CONSTRAINT `fk_review_submission` FOREIGN KEY (`submission_id`) REFERENCES `task_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_submissions`
--
ALTER TABLE `task_submissions`
  ADD CONSTRAINT `fk_submission_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_submission_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_army_profiles`
--
ALTER TABLE `user_army_profiles`
  ADD CONSTRAINT `fk_user_army_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_army_profiles_ibfk_1` FOREIGN KEY (`army_level_id`) REFERENCES `army_levels` (`id`);

--
-- Constraints for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD CONSTRAINT `fk_user_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `fk_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_wallets_user_v2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD CONSTRAINT `fk_wallet_tx_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_wallet_tx_user_v2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
